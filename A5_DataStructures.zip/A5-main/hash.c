#include "hash.h"

struct HashTable *createTable( struct memsys *memsys,unsigned int capacity,unsigned int width,int (*hash)( void *, int ),int (*compar)(const void *, const void *)){
    struct HashTable *table =  malloc(sizeof(struct HashTable));
    table->capacity = capacity;
    table->nel=0;
    table->width=width;
    table->hash=hash;
    table->compar=compar;
    table->data=memmalloc(memsys,sizeof(int)*capacity);
    int memnull = MEMNULL;
    for(int i=0;i<table->capacity;i++)
        setval(memsys,&memnull,sizeof(int), table->data+i*sizeof(int));
    return table;
}
void addElement( struct memsys *memsys, struct HashTable *table, int addr ){
    if(table->nel == table->capacity){
        fprintf(stderr,"table is full");
        exit(-1);
    }

    void * data = malloc(table->width);
    getval(memsys,data,table->width,addr);
    int hashIndex = table->hash(data,table->capacity);
    int memIndex = table->data + hashIndex*sizeof(int);
    int memIndexVal;
    getval(memsys,&memIndexVal,sizeof(int),memIndex);

    while(memIndexVal != MEMNULL){
        hashIndex++;
        if(hashIndex == table->capacity){
            hashIndex=0;
        }
        memIndex = table->data + hashIndex*sizeof(int);
        getval(memsys,&memIndexVal,sizeof(int),memIndex);
    }

    setval(memsys,&addr,sizeof(int),memIndex);
    table->nel++;
    free(data);

}
int getElement( struct memsys *memsys, struct HashTable *table, void *key ){

    int hashIndex = table->hash(key,table->capacity);
    int hashIndex2 = hashIndex;
    void * data = malloc(table->width);
    int memIndex = table->data+hashIndex*sizeof(int);
    int memAddr;
    getval(memsys,&memAddr,sizeof(int),memIndex);
    if(memAddr!=MEMNULL)
        getval(memsys,data,table->width,memAddr);


    while(table->compar(key,data)!=0){
        hashIndex++;
        if(hashIndex == hashIndex2){
            free(data);
            return MEMNULL;
        }

        if(hashIndex == table->capacity){
            hashIndex=0;
        }

        memIndex = table->data+hashIndex*sizeof(int);
        getval(memsys,&memAddr,sizeof(int),memIndex);
        if(memAddr!=MEMNULL){
            getval(memsys,data,table->width,memAddr);
        }

    }
    free(data);
    return memAddr;
}

void freeTable(struct memsys * memsys, struct HashTable * table){
    memfree(memsys,table->data);
    free(table);
}
int hashAccuracy( struct memsys *memsys, struct HashTable *table ){

    int index = 0;
    int accuracy=0;
    void * data = malloc(table->width);
    while(index<table->capacity){

        int memIndex = table->data+index*sizeof(int);
        int memAddr;
        getval(memsys,&memAddr,sizeof(int),memIndex);
        if(memAddr!=MEMNULL){
            getval(memsys,data,table->width,memAddr);
            int hash = table->hash(data,table->capacity);
            if(index < hash){
                accuracy+= table->capacity - index + hash;
            }else{
                accuracy+= index - hash;
            }
        }
        index++;
    }
    return accuracy;
}

